import React, { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { ArrowRight, Heart, LogOut, Loader2, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import { formatPrice } from "@/lib/cart";
import { useWishlist } from "@/lib/wishlist";

const TABS = [
  { key: "orders", label: "Orders" },
  { key: "wishlist", label: "Wishlist" },
  { key: "profile", label: "Profile" },
];

export default function Account() {
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") || "orders";
  const [me, setMe] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const { items: wishlist, setItems: setWishlist } = useWishlist();

  useEffect(() => {
    (async () => {
      const user = await base44.auth.me();
      setMe(user);
      const page = await base44.entities.Order.filter({}, { sort: "-created_date", limit: 50 });
      setOrders(page.items || []);
      setLoading(false);
    })();
  }, []);

  const removeWish = async (id) => {
    await base44.entities.WishlistItem.delete(id);
    setWishlist((prev) => prev.filter((i) => i.id !== id));
  };

  return (
    <div className="mx-auto max-w-[1200px] px-4 pt-10 md:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-border pb-6">
        <div>
          <p className="mono-label">Identity verified</p>
          <h1 className="mt-2 font-display text-4xl font-extrabold uppercase tracking-tight md:text-5xl">
            {me?.full_name || "Your archive"}
          </h1>
          <p className="mono-label mt-2">{me?.email}</p>
        </div>
        <button
          onClick={() => base44.auth.logout()}
          className="inline-flex items-center gap-2 border border-border px-4 py-2.5 font-mono text-[10px] uppercase tracking-[0.16em] hover:border-foreground"
        >
          <LogOut className="h-3.5 w-3.5" /> Sign out
        </button>
      </div>

      <div className="mt-6 flex gap-2">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setParams(t.key === "orders" ? {} : { tab: t.key }, { replace: true })}
            className={`border px-4 py-2 font-mono text-[10px] uppercase tracking-[0.16em] ${
              tab === t.key
                ? "border-foreground bg-foreground text-background"
                : "border-border text-foreground/70 hover:border-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="mt-10 min-h-[40vh]">
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : tab === "orders" ? (
          orders.length === 0 ? (
            <Empty
              title="No orders yet"
              copy="Your next drop is waiting. Everything you buy will live here."
            />
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <Link
                  key={order.id}
                  to={`/orders/${order.id}`}
                  className="block border border-border bg-card p-5 transition-colors hover:border-foreground"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="font-mono text-xs">{order.order_number}</p>
                      <p className="mono-label mt-1">
                        {new Date(order.created_date).toLocaleDateString("en-IN", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric",
                        })}
                      </p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="border border-border px-2 py-1 font-mono text-[9px] uppercase tracking-[0.14em]">
                        {order.status}
                      </span>
                      <p className="font-mono text-sm">{formatPrice(order.total)}</p>
                      <ArrowRight className="h-4 w-4" />
                    </div>
                  </div>
                  <p className="mt-3 text-xs text-muted-foreground">
                    {(order.items || []).map((i) => `${i.name} (${i.size})`).join(" · ")}
                  </p>
                </Link>
              ))}
            </div>
          )
        ) : tab === "wishlist" ? (
          wishlist.length === 0 ? (
            <Empty title="Wishlist is empty" copy="Tap the heart on any piece to keep it here." />
          ) : (
            <div className="grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-4">
              {wishlist.map((item) => (
                <div key={item.id} className="group relative">
                  <Link to={`/product/${item.slug}`} className="block aspect-[4/5] overflow-hidden bg-secondary">
                    <Image src={item.image} alt={item.name} className="h-full w-full" fittingType="fill" />
                  </Link>
                  <button
                    onClick={() => removeWish(item.id)}
                    aria-label={`Remove ${item.name}`}
                    className="absolute right-2 top-2 grid h-8 w-8 place-items-center bg-background/90 backdrop-blur"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                  <div className="mt-2 flex justify-between gap-2">
                    <Link to={`/product/${item.slug}`} className="text-xs font-medium hover:underline">
                      {item.name}
                    </Link>
                    <span className="font-mono text-[11px]">{formatPrice(item.price)}</span>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : (
          <div className="max-w-md border border-border bg-card p-6">
            <p className="mono-label">Account details</p>
            <dl className="mt-4 space-y-4 text-sm">
              <div>
                <dt className="mono-label">Name</dt>
                <dd className="mt-1">{me?.full_name || "—"}</dd>
              </div>
              <div>
                <dt className="mono-label">Email</dt>
                <dd className="mt-1">{me?.email}</dd>
              </div>
              <div>
                <dt className="mono-label">Access level</dt>
                <dd className="mt-1 uppercase">{me?.role === "admin" ? "Studio admin" : "Member"}</dd>
              </div>
            </dl>
            <p className="mt-6 border-t border-border pt-4 text-xs leading-relaxed text-muted-foreground">
              Orders, wishlist and early drop access are tied to this identity. Contact the studio at{" "}
              <a href="mailto:beaantriksh@gmail.com" className="underline underline-offset-4">
                beaantriksh@gmail.com
              </a>{" "}
              for anything else.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function Empty({ title, copy }) {
  return (
    <div className="border border-dashed border-border py-20 text-center">
      <Heart className="mx-auto h-6 w-6 text-muted-foreground" />
      <p className="mt-4 font-display text-2xl font-extrabold uppercase">{title}</p>
      <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">{copy}</p>
      <Link
        to="/shop"
        className="mt-6 inline-flex items-center gap-2 bg-foreground px-6 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-background"
      >
        Shop the collection <ArrowRight className="h-3.5 w-3.5" />
      </Link>
    </div>
  );
}