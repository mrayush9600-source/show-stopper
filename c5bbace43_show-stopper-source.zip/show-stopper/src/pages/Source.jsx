import React from "react";
import { Download, FolderOpen, Terminal, FileCode2, ArrowRight } from "lucide-react";
import Marquee from "@/components/Marquee";

const DOWNLOAD_URL =
  "https://base44.app/api/apps/6ad8b57d9881b089c2bbeb55/files/mp/public/6ad8b57d9881b089c2bbeb55/6f7ae69b5_show-stopper-source.zip";
const BUILD_DATE = "12 November 2026";

const STEPS = [
  {
    icon: FolderOpen,
    title: "Open it in VS Code",
    body: "Download, extract, then File → Open Folder and pick the extracted folder. Every file is there.",
    code: "show-stopper/\n  src/        pages, components, cart, auth\n  base44/     entities + notifyOrder\n  package.json",
  },
  {
    icon: Terminal,
    title: "Run it — no account needed",
    body: "Standalone mode boots the full store from a bundled catalog and the browser:",
    code: "npm install\nnpx vite --config src/standalone/vite.config.js",
  },
  {
    icon: Terminal,
    title: "Or connect a real backend",
    body: "Same code against live accounts, database and order emails on Base44:",
    code: "npm install -g base44@latest\nbase44 login\nbase44 link\nbase44 dev",
  },
];

const GIT = `git init
git add .
git commit -m "Show Stopper storefront"
git branch -M main
git remote add origin https://github.com/<you>/show-stopper.git
git push -u origin main`;

const INCLUDED = [
  ["Standalone mode", "Local data layer and seed catalog — runs with no Base44 account"],
  ["Frontend", "React + Vite pages, components, cart and wishlist state"],
  ["Design system", "Tailwind config and the Archivo / Inter token set"],
  ["Data model", "Product, Order and WishlistItem schemas with access rules"],
  ["Backend", "The notifyOrder function that emails each new order"],
  ["Docs", "README with every local setup and publishing command"],
];

export default function Source() {
  return (
    <div>
      <section className="border-b border-border">
        <div className="mx-auto max-w-[1600px] px-4 py-16 md:px-8 md:py-24">
          <p className="mono-label">Open handoff / Source archive</p>
          <h1 className="display-tight mt-4 max-w-3xl text-5xl md:text-7xl">
            Take the
            <br />
            code home
          </h1>
          <p className="mt-6 max-w-xl text-sm leading-relaxed text-muted-foreground">
            The whole Show Stopper store — every page, component, schema and API call — as a single
            archive. Open it in VS Code and it runs: no account needed for the standalone mode, or
            point the same code at a real backend when you want live orders.
          </p>

          <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:items-center">
            <a
              href={DOWNLOAD_URL}
              download="show-stopper-source.zip"
              className="group inline-flex items-center justify-center gap-3 bg-foreground px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-background transition-colors hover:bg-accent hover:text-foreground"
            >
              <Download className="h-4 w-4" />
              Download source (.zip)
            </a>
            <p className="mono-label">
              {BUILD_DATE} · 205 KB · 119 files
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1600px] px-4 py-16 md:px-8">
        <p className="mono-label">01 / Run it locally</p>
        <div className="mt-8 grid gap-px border border-border bg-border md:grid-cols-3">
          {STEPS.map((step) => {
            const Icon = step.icon;
            return (
              <div key={step.title} className="bg-background p-6">
                <Icon className="h-5 w-5 text-accent-foreground" strokeWidth={1.5} />
                <h2 className="mt-5 font-display text-lg font-extrabold uppercase leading-tight tracking-tight">
                  {step.title}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                {step.code && (
                  <pre className="mt-4 overflow-x-auto border border-border bg-secondary/50 p-3 font-mono text-[11px] leading-relaxed">
                    {step.code}
                  </pre>
                )}
              </div>
            );
          })}
        </div>
        <p className="mt-6 max-w-2xl font-mono text-[10px] uppercase leading-relaxed tracking-[0.18em] text-muted-foreground">
          Standalone mode mocks sign-in, order emails and payments — the catalog, cart, wishlist and
          orders are real, stored in the browser. Need an app id for{" "}
          <span className="text-foreground">base44 link</span>? It sits in the Builder URL
          (app.base44.com/apps/&lt;id&gt;). Never run plain npm run dev once linked — start with base44 dev.
        </p>
      </section>

      <section className="mx-auto max-w-[1600px] px-4 pb-20 md:px-8">
        <div className="grid gap-10 border-t border-border pt-12 md:grid-cols-[1fr_1.2fr]">
          <div>
            <p className="mono-label">Git / Your own repo</p>
            <h2 className="display-tight mt-3 text-4xl md:text-5xl">
              Push it to
              <br />
              GitHub
            </h2>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-muted-foreground">
              The folder is a plain git repository — no lock-in. Commit it, push it, hand it to any
              developer, or deploy the frontend wherever you like.
            </p>
          </div>
          <pre className="overflow-x-auto border border-border bg-secondary/50 p-5 font-mono text-[11px] leading-relaxed">
            {GIT}
          </pre>
        </div>
      </section>

      <section className="mx-auto max-w-[1600px] px-4 pb-20 md:px-8">
        <div className="grid gap-10 border-t border-border pt-12 md:grid-cols-[1fr_1.2fr]">
          <div>
            <p className="mono-label">02 / What's inside</p>
            <h2 className="display-tight mt-3 text-4xl md:text-5xl">
              Everything,
              <br />
              nothing hidden
            </h2>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-muted-foreground">
              Product images and store data stay in your Base44 app; the archive carries the full
              codebase that renders them.
            </p>
            <a
              href={DOWNLOAD_URL}
              download="show-stopper-source.zip"
              className="mt-8 inline-flex items-center gap-2 border-b border-accent pb-1 font-mono text-[11px] uppercase tracking-[0.2em]"
            >
              Get the archive <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>

          <dl className="divide-y divide-border border-y border-border">
            {INCLUDED.map(([title, body]) => (
              <div key={title} className="flex flex-col gap-1 py-4 sm:flex-row sm:gap-6">
                <dt className="flex w-40 shrink-0 items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em]">
                  <FileCode2 className="h-3.5 w-3.5 text-accent-foreground" />
                  {title}
                </dt>
                <dd className="text-sm text-muted-foreground">{body}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <Marquee />
    </div>
  );
}