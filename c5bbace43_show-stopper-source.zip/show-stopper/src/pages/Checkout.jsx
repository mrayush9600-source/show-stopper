import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Loader2, Lock } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import { useCart, formatPrice } from "@/lib/cart";

const FIELDS = [
  { name: "customer_name", label: "Full name", placeholder: "Ananya Sharma", span: 2 },
  { name: "email", label: "Email", placeholder: "you@example.com", type: "email", span: 1 },
  { name: "phone", label: "Phone", placeholder: "98765 43210", span: 1 },
  { name: "address", label: "Address", placeholder: "Flat, street, landmark", span: 2 },
  { name: "city", label: "City", placeholder: "New Delhi", span: 1 },
  { name: "state", label: "State", placeholder: "Delhi", span: 1 },
  { name: "pincode", label: "Pincode", placeholder: "110001", span: 1 },
];

export default function Checkout() {
  const { items, subtotal, shipping, total, clear } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    customer_name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    notes: "",
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    (async () => {
      const me = await base44.auth.me();
      if (me) {
        setForm((prev) => ({
          ...prev,
          customer_name: prev.customer_name || me.full_name || "",
          email: prev.email || me.email || "",
        }));
      }
    })();
  }, []);

  const update = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: "" }));
  };

  const validate = () => {
    const next = {};
    if (!form.customer_name.trim()) next.customer_name = "Name is required";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) next.email = "Valid email required";
    if (!/^[0-9+\s-]{10,15}$/.test(form.phone)) next.phone = "Valid phone required";
    if (form.address.trim().length < 8) next.address = "Full address required";
    if (!form.city.trim()) next.city = "City is required";
    if (!form.state.trim()) next.state = "State is required";
    if (!/^\d{6}$/.test(form.pincode)) next.pincode = "6 digit pincode";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const placeOrder = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    try {
      const order = await base44.entities.Order.create({
        order_number: "SS-" + Math.random().toString(36).slice(2, 8).toUpperCase(),
        ...form,
        items: items.map((i) => ({
          product_id: i.product_id,
          name: i.name,
          size: i.size,
          qty: i.qty,
          price: i.price,
          image: i.image,
        })),
        subtotal,
        shipping,
        total,
        status: "placed",
        payment_method: "Cash on delivery",
      });
      clear();
      base44.functions.invoke("notifyOrder", { orderId: order.id }).catch(() => {});
      navigate(`/orders/${order.id}`, { replace: true });
    } catch (err) {
      setErrors({ form: err.message || "Could not place the order. Try again." });
      setSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-4 py-28 text-center">
        <h1 className="display-tight text-4xl">Nothing to check out</h1>
        <p className="mt-4 text-sm text-muted-foreground">Your bag is empty right now.</p>
        <Link to="/shop" className="mt-8 inline-flex items-center gap-2 bg-foreground px-7 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-background">
          Shop the collection <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1200px] px-4 pt-10 md:px-8">
      <div className="border-b border-border pb-5">
        <p className="mono-label">Secure terminal</p>
        <h1 className="mt-2 font-display text-4xl font-extrabold uppercase tracking-tight md:text-5xl">
          Checkout
        </h1>
      </div>

      <form onSubmit={placeOrder} className="mt-8 grid gap-12 md:grid-cols-[1.4fr_1fr]">
        <div>
          <p className="mono-label">Delivery details</p>
          <div className="mt-4 grid grid-cols-2 gap-4">
            {FIELDS.map((field) => (
              <div key={field.name} className={field.span === 2 ? "col-span-2" : "col-span-2 sm:col-span-1"}>
                <label htmlFor={field.name} className="mono-label">
                  {field.label}
                </label>
                <input
                  id={field.name}
                  type={field.type || "text"}
                  value={form[field.name]}
                  onChange={(e) => update(field.name, e.target.value)}
                  placeholder={field.placeholder}
                  className="mt-2 w-full border border-border bg-card px-3 py-3 text-sm outline-none focus:border-foreground"
                />
                {errors[field.name] && (
                  <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.1em] text-destructive">
                    {errors[field.name]}
                  </p>
                )}
              </div>
            ))}
            <div className="col-span-2">
              <label htmlFor="notes" className="mono-label">Order note (optional)</label>
              <textarea
                id="notes"
                rows={3}
                value={form.notes}
                onChange={(e) => update("notes", e.target.value)}
                placeholder="Gate code, delivery preference…"
                className="mt-2 w-full border border-border bg-card px-3 py-3 text-sm outline-none focus:border-foreground"
              />
            </div>
          </div>

          <div className="mt-8 border border-border bg-secondary/50 p-4">
            <p className="font-mono text-[11px] uppercase tracking-[0.14em]">Payment method</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Cash on delivery — pay the courier when your parcel arrives. Our team confirms every
              order by email before dispatch.
            </p>
          </div>

          {errors.form && (
            <p className="mt-4 border border-destructive/40 bg-destructive/10 p-3 font-mono text-[11px] text-destructive">
              {errors.form}
            </p>
          )}
        </div>

        <aside className="h-fit border border-border bg-card p-6 md:sticky md:top-32">
          <p className="mono-label">Order summary</p>
          <div className="mt-4 space-y-4">
            {items.map((item) => (
              <div key={item.lineId} className="flex gap-3">
                <div className="h-20 w-16 shrink-0 overflow-hidden bg-secondary">
                  <Image src={item.image} alt={item.name} className="h-full w-full" fittingType="fill" />
                </div>
                <div className="flex flex-1 justify-between gap-2">
                  <div>
                    <p className="text-xs font-medium leading-snug">{item.name}</p>
                    <p className="mono-label mt-1">Size {item.size} · Qty {item.qty}</p>
                  </div>
                  <p className="font-mono text-[11px]">{formatPrice(item.price * item.qty)}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-5 space-y-2 border-t border-border pt-4 font-mono text-[11px] uppercase tracking-[0.12em]">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal</span>
              <span>{formatPrice(subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Shipping</span>
              <span>{shipping === 0 ? "Free" : formatPrice(shipping)}</span>
            </div>
            <div className="flex justify-between border-t border-border pt-2 text-sm">
              <span>Total</span>
              <span>{formatPrice(total)}</span>
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="mt-6 flex w-full items-center justify-center gap-2 bg-foreground py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-background transition-colors hover:bg-accent hover:text-foreground disabled:opacity-60"
          >
            {submitting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Lock className="h-3.5 w-3.5" />}
            {submitting ? "Placing order" : "Place order"}
          </button>
          <p className="mono-label mt-4 text-center">A copy goes straight to the studio inbox</p>
        </aside>
      </form>
    </div>
  );
}