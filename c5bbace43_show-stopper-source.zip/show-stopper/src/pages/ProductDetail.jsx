import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Heart, Loader2, Truck, RotateCcw, ShieldCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import ProductGrid from "@/components/products/ProductGrid";
import { useCart, formatPrice } from "@/lib/cart";
import { useWishlist } from "@/lib/wishlist";

const SIZES = ["S", "M", "L", "XL", "XXL"];

export default function ProductDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { add } = useCart();
  const { isSaved, toggle } = useWishlist();
  const [product, setProduct] = useState(null);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(true);
  const [size, setSize] = useState("");
  const [lens, setLens] = useState(null);
  const frameRef = useRef(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setSize("");
    (async () => {
      const page = await base44.entities.Product.filter({ slug }, { limit: 1 });
      const found = page.items?.[0] || null;
      if (!active) return;
      setProduct(found);
      setLoading(false);
      if (found) {
        const more = await base44.entities.Product.filter(
          { category: found.category, id: { $ne: found.id } },
          { limit: 4 }
        );
        if (active) setRelated(more.items || []);
      }
    })();
    return () => {
      active = false;
    };
  }, [slug]);

  const handleMove = (e) => {
    const rect = frameRef.current?.getBoundingClientRect();
    if (!rect) return;
    setLens({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  };

  if (loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="mx-auto max-w-xl px-4 py-28 text-center">
        <p className="font-display text-3xl font-extrabold uppercase">Piece not found</p>
        <p className="mt-3 text-sm text-muted-foreground">
          This garment may have sold out or left the archive.
        </p>
        <Link to="/shop" className="mt-6 inline-flex items-center gap-2 bg-foreground px-6 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-background">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to collection
        </Link>
      </div>
    );
  }

  const sizes = product.sizes?.length ? product.sizes : SIZES;
  const saved = isSaved(product.id);
  const specs = product.specs?.length
    ? product.specs
    : ["240 GSM combed cotton", "Boxy oversized fit", "Screen printed by hand", "Cold machine wash"];

  const handleSave = async () => {
    const done = await toggle(product);
    if (!done) navigate("/login");
  };

  return (
    <div className="mx-auto max-w-[1600px] px-4 pt-6 md:px-8">
      <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        <Link to="/shop" className="hover:text-foreground">Archive</Link>
        <span>/</span>
        <span className="text-foreground">{product.category}</span>
      </div>

      <div className="mt-6 grid gap-10 md:grid-cols-[1.6fr_1fr] md:gap-14">
        <div
          ref={frameRef}
          onMouseMove={handleMove}
          onMouseLeave={() => setLens(null)}
          className="relative aspect-[4/5] w-full cursor-crosshair overflow-hidden bg-secondary"
        >
          <Image src={product.images?.[0]} alt={product.name} className="h-full w-full" fittingType="fill" />
          {lens && (
            <div
              className="pointer-events-none absolute hidden h-44 w-44 rounded-full border border-background/70 shadow-xl md:block"
              style={{
                left: `calc(${lens.x}% - 88px)`,
                top: `calc(${lens.y}% - 88px)`,
                backgroundImage: `url(${product.images?.[0]})`,
                backgroundSize: "260%",
                backgroundPosition: `${lens.x}% ${lens.y}%`,
              }}
            />
          )}
          <div className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-accent/20 to-transparent scanner-line" />
        </div>

        <div className="md:sticky md:top-32 md:self-start">
          <div className="flex items-start justify-between gap-4">
            <div>
              {product.is_new && (
                <span className="inline-block bg-accent px-2 py-1 font-mono text-[9px] uppercase tracking-[0.16em]">
                  New drop
                </span>
              )}
              <h1 className="mt-3 font-display text-3xl font-extrabold uppercase leading-none tracking-tight md:text-4xl">
                {product.name}
              </h1>
              <p className="mono-label mt-3">
                {product.colorway} {product.drop ? `· ${product.drop}` : ""}
              </p>
            </div>
            <button
              onClick={handleSave}
              aria-label="Save to wishlist"
              className="grid h-10 w-10 shrink-0 place-items-center border border-border"
            >
              <Heart className={`h-4 w-4 ${saved ? "fill-foreground" : ""}`} />
            </button>
          </div>

          <div className="mt-5 flex items-baseline gap-3">
            <p className="font-mono text-lg">{formatPrice(product.price)}</p>
            {product.compare_price > product.price && (
              <p className="font-mono text-xs text-muted-foreground line-through">
                {formatPrice(product.compare_price)}
              </p>
            )}
            <span className="mono-label">Incl. of all taxes</span>
          </div>

          <p className="mt-5 text-sm leading-relaxed text-muted-foreground">{product.description}</p>

          <div className="mt-7">
            <div className="flex items-center justify-between">
              <p className="mono-label">Select size</p>
              <span className="mono-label">{size ? `Size ${size}` : "Required"}</span>
            </div>
            <div className="mt-3 grid grid-cols-5 gap-2">
              {sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={`py-3 font-mono text-[11px] uppercase tracking-[0.12em] transition-colors ${
                    size === s
                      ? "bg-foreground text-background"
                      : "border border-border hover:border-foreground"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => size && add(product, size)}
            disabled={!size}
            className="mt-5 flex w-full items-center justify-center gap-2 bg-foreground py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-background transition-colors hover:bg-accent hover:text-foreground disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground"
          >
            {size ? "Add to bag" : "Choose a size"}
          </button>

          <dl className="mt-7 space-y-3 border-t border-border pt-6">
            {specs.map((spec) => (
              <div key={spec} className="flex items-start gap-3">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-accent" />
                <dd className="font-mono text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
                  {spec}
                </dd>
              </div>
            ))}
          </dl>

          {product.story && (
            <p className="mt-6 border-l-2 border-accent pl-4 text-sm leading-relaxed text-muted-foreground">
              {product.story}
            </p>
          )}

          <div className="mt-7 grid gap-3 border-t border-border pt-6 text-[11px] text-muted-foreground">
            <p className="flex items-center gap-2"><Truck className="h-4 w-4" /> Free shipping over ₹2,999 · dispatch in 48h</p>
            <p className="flex items-center gap-2"><RotateCcw className="h-4 w-4" /> 7 day returns on unworn pieces</p>
            <p className="flex items-center gap-2"><ShieldCheck className="h-4 w-4" /> Cash on delivery available</p>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-24">
          <div className="border-b border-border pb-4">
            <p className="mono-label">You may also like</p>
          </div>
          <div className="mt-8">
            <ProductGrid products={related} columns={4} />
          </div>
        </section>
      )}
    </div>
  );
}