import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowRight, Check, Loader2, Package } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import { formatPrice } from "@/lib/cart";

const STEPS = ["placed", "packed", "shipped", "delivered"];

export default function OrderConfirmation() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const record = await base44.entities.Order.get(id);
        if (active) setOrder(record);
      } catch {
        if (active) setOrder(null);
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [id]);

  if (loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="mx-auto max-w-xl px-4 py-28 text-center">
        <p className="font-display text-3xl font-extrabold uppercase">Order not found</p>
        <p className="mt-3 text-sm text-muted-foreground">This order does not belong to your account.</p>
        <Link to="/account" className="mt-6 inline-flex items-center gap-2 bg-foreground px-6 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-background">
          My orders <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    );
  }

  const stepIndex = Math.max(0, STEPS.indexOf(order.status));

  return (
    <div className="mx-auto max-w-[1000px] px-4 pt-12 md:px-8">
      <div className="border-b border-border pb-6">
        <p className="mono-label">Order confirmed</p>
        <h1 className="mt-2 font-display text-4xl font-extrabold uppercase tracking-tight md:text-5xl">
          {order.order_number}
        </h1>
        <p className="mt-3 max-w-lg text-sm text-muted-foreground">
          Thank you, {order.customer_name.split(" ")[0]}. Your pieces are locked in and a copy of
          this order has been sent to the studio. We dispatch within 48 hours.
        </p>
      </div>

      <div className="mt-8 grid gap-10 md:grid-cols-[1.4fr_1fr]">
        <div>
          <div className="flex items-center justify-between">
            {STEPS.map((step, i) => (
              <div key={step} className="flex flex-1 items-center gap-2">
                <div
                  className={`grid h-7 w-7 shrink-0 place-items-center rounded-full font-mono text-[10px] ${
                    i <= stepIndex ? "bg-foreground text-background" : "border border-border text-muted-foreground"
                  }`}
                >
                  {i <= stepIndex ? <Check className="h-3.5 w-3.5" /> : i + 1}
                </div>
                <span className="mono-label hidden sm:block">{step}</span>
                {i < STEPS.length - 1 && (
                  <span className={`h-px flex-1 ${i < stepIndex ? "bg-foreground" : "bg-border"}`} />
                )}
              </div>
            ))}
          </div>

          <div className="mt-8 border-t border-border">
            {(order.items || []).map((item) => (
              <div key={`${item.name}-${item.size}`} className="flex gap-4 border-b border-border py-4">
                <div className="h-24 w-20 shrink-0 overflow-hidden bg-secondary">
                  <Image src={item.image} alt={item.name} className="h-full w-full" fittingType="fill" />
                </div>
                <div className="flex flex-1 justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium">{item.name}</p>
                    <p className="mono-label mt-1">Size {item.size} · Qty {item.qty}</p>
                  </div>
                  <p className="font-mono text-xs">{formatPrice(item.price * item.qty)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <aside className="h-fit space-y-6 border border-border bg-card p-6">
          <div>
            <p className="mono-label">Total paid on delivery</p>
            <p className="mt-2 font-display text-3xl font-extrabold">{formatPrice(order.total)}</p>
            <p className="mono-label mt-1">Cash on delivery</p>
          </div>
          <div className="border-t border-border pt-4">
            <p className="mono-label">Shipping to</p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {order.customer_name}
              <br />
              {order.address}
              <br />
              {order.city}, {order.state} {order.pincode}
              <br />
              {order.phone}
            </p>
          </div>
          <div className="border-t border-border pt-4">
            <p className="mono-label">Need help?</p>
            <a href="mailto:beaantriksh@gmail.com" className="mt-2 block text-sm underline underline-offset-4">
              beaantriksh@gmail.com
            </a>
          </div>
          <Link
            to="/shop"
            className="flex items-center justify-center gap-2 bg-foreground py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-background"
          >
            <Package className="h-3.5 w-3.5" /> Keep shopping
          </Link>
        </aside>
      </div>
    </div>
  );
}