import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, Lock, Loader2, ArrowLeft } from "lucide-react";
import GoogleIcon from "@/components/GoogleIcon";
import { safeReturnTo } from "@/lib/authReturnTo";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(false);
  const returnTo = safeReturnTo();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      window.location.href = returnTo;
    } catch (err) {
      setError(err.message || "Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => {
    base44.auth.loginWithProvider("google", returnTo);
  };

  return (
    <div className="grid min-h-screen bg-background md:grid-cols-2">
      <div className="relative hidden flex-col justify-between overflow-hidden bg-foreground p-10 text-background md:flex">
        <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.3em] text-background/50">
          <span>Identity portal</span>
          <span>BLU / 004</span>
        </div>

        <div className="relative">
          <div className="relative mx-auto mb-12 grid h-40 w-40 place-items-center rounded-full border border-background/20">
            <div className="absolute inset-0 rounded-full border border-accent/30 scanner-line" />
            <div
              className="grid h-16 w-16 place-items-center rounded-full bg-accent transition-transform duration-300 ease-out"
              style={{
                transform: active ? "scale(1.15)" : "scale(1)",
              }}
            >
              <div className="h-6 w-6 rounded-full bg-foreground" />
            </div>
          </div>
          <h1 className="display-tight text-[5vw] leading-[0.85] text-background">
            Verify
            <br />
            your
            <br />
            identity
          </h1>
          <p className="mt-6 max-w-xs text-sm leading-relaxed text-background/60">
            Members see drops 24 hours early, keep a permanent wishlist and track every order to
            their door.
          </p>
        </div>

        <div className="flex items-center justify-between border-t border-white/10 pt-6 font-mono text-[10px] uppercase tracking-[0.22em] text-background/40">
          <span>Encrypted session</span>
          <span>{active ? "Signal live" : "Awaiting signal"}</span>
        </div>
      </div>

      <div className="flex items-center justify-center px-5 py-14">
        <div className="w-full max-w-md">
          <Link
            to="/"
            className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Back to store
          </Link>

          <div className="mt-10">
            <p className="mono-label">Step 01 / Access</p>
            <h2 className="mt-3 font-display text-4xl font-extrabold uppercase tracking-tight">
              Log in
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Enter your credentials to open your archive.
            </p>
          </div>

          <Button
            variant="outline"
            className="mt-8 h-12 w-full rounded-none text-sm font-medium"
            onClick={handleGoogle}
          >
            <GoogleIcon className="mr-2 h-5 w-5" />
            Continue with Google
          </Button>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-[10px] uppercase">
              <span className="bg-background px-3 font-mono tracking-[0.2em] text-muted-foreground">
                or
              </span>
            </div>
          </div>

          {error && (
            <div className="mb-4 border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="mono-label">
                Email
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  autoFocus
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onFocus={() => setActive(true)}
                  onBlur={() => setActive(false)}
                  className="h-12 rounded-none pl-10"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="mono-label">
                  Password
                </Label>
                <Link to="/forgot-password" className="font-mono text-[10px] uppercase tracking-[0.14em] underline underline-offset-4">
                  Forgot?
                </Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                <Input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onFocus={() => setActive(true)}
                  onBlur={() => setActive(false)}
                  className="h-12 rounded-none pl-10"
                  required
                />
              </div>
            </div>
            <Button
              type="submit"
              className="h-12 w-full rounded-none bg-foreground font-mono text-[11px] uppercase tracking-[0.2em] text-background hover:bg-accent hover:text-foreground"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying…
                </>
              ) : (
                "Verify & enter"
              )}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            No identity yet?{" "}
            <Link
              to={"/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "")}
              className="font-medium text-foreground underline underline-offset-4"
            >
              Create one
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}