import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Minus, Plus, Trash2 } from "lucide-react";
import { Image } from "@/components/ui/image";
import { useCart, formatPrice, FREE_SHIPPING_THRESHOLD } from "@/lib/cart";

export default function Cart() {
  const { items, setQty, remove, subtotal, shipping, total } = useCart();
  const remaining = FREE_SHIPPING_THRESHOLD - subtotal;

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-4 py-28 text-center">
        <p className="mono-label">Manifest / 00</p>
        <h1 className="display-tight mt-4 text-4xl">Your bag is empty</h1>
        <p className="mt-4 text-sm text-muted-foreground">
          Start with the Stag Bloom drop — heavyweight cotton, numbered run.
        </p>
        <Link
          to="/shop"
          className="mt-8 inline-flex items-center gap-2 bg-foreground px-7 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-background"
        >
          Shop the collection <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1200px] px-4 pt-10 md:px-8">
      <div className="border-b border-border pb-5">
        <p className="mono-label">Manifest / {String(items.length).padStart(2, "0")}</p>
        <h1 className="mt-2 font-display text-4xl font-extrabold uppercase tracking-tight md:text-5xl">
          Your bag
        </h1>
      </div>

      <div className="mt-8 grid gap-12 md:grid-cols-[1.6fr_1fr]">
        <div>
          {items.map((item) => (
            <div key={item.lineId} className="flex gap-4 border-b border-border py-6 md:gap-6">
              <Link to={`/product/${item.slug}`} className="h-32 w-24 shrink-0 overflow-hidden bg-secondary md:h-40 md:w-32">
                <Image src={item.image} alt={item.name} className="h-full w-full" fittingType="fill" />
              </Link>
              <div className="flex flex-1 flex-col">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <Link to={`/product/${item.slug}`} className="font-medium hover:underline">
                      {item.name}
                    </Link>
                    <p className="mono-label mt-1">Size {item.size}</p>
                  </div>
                  <p className="font-mono text-sm">{formatPrice(item.price * item.qty)}</p>
                </div>
                <div className="mt-auto flex items-center justify-between pt-4">
                  <div className="flex items-center border border-border">
                    <button onClick={() => setQty(item.lineId, item.qty - 1)} className="px-3 py-2" aria-label="Decrease quantity">
                      <Minus className="h-3 w-3" />
                    </button>
                    <span className="w-8 text-center font-mono text-xs tabular-nums">{item.qty}</span>
                    <button onClick={() => setQty(item.lineId, item.qty + 1)} className="px-3 py-2" aria-label="Increase quantity">
                      <Plus className="h-3 w-3" />
                    </button>
                  </div>
                  <button
                    onClick={() => remove(item.lineId)}
                    className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" /> Remove
                  </button>
                </div>
              </div>
            </div>
          ))}
          <Link
            to="/shop"
            className="mt-6 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] underline underline-offset-4"
          >
            <ArrowRight className="h-3.5 w-3.5 rotate-180" /> Continue shopping
          </Link>
        </div>

        <aside className="h-fit border border-border bg-card p-6 md:sticky md:top-32">
          <p className="mono-label">Summary</p>
          <div className="mt-5 space-y-2 font-mono text-[11px] uppercase tracking-[0.12em]">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal</span>
              <span>{formatPrice(subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Shipping</span>
              <span>{shipping === 0 ? "Free" : formatPrice(shipping)}</span>
            </div>
          </div>
          {remaining > 0 && (
            <p className="mono-label mt-4 border-t border-border pt-4">
              {formatPrice(remaining)} more for free shipping
            </p>
          )}
          <div className="mt-5 flex justify-between border-t border-border pt-4 font-mono text-sm">
            <span>Total</span>
            <span>{formatPrice(total)}</span>
          </div>
          <Link
            to="/checkout"
            className="mt-6 flex items-center justify-center gap-2 bg-foreground py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-background transition-colors hover:bg-accent hover:text-foreground"
          >
            Checkout <ArrowRight className="h-3.5 w-3.5" />
          </Link>
          <p className="mono-label mt-4 text-center">Cash on delivery · 7 day returns</p>
        </aside>
      </div>
    </div>
  );
}