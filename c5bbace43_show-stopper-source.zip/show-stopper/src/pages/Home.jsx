import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import ProductGrid from "@/components/products/ProductGrid";
import Marquee from "@/components/Marquee";

const HERO = "https://media.base44.com/images/public/6ad8b57d9881b089c2bbeb55/402ae6b5e_generated_e4b0bcad.png";
const STILL = "https://media.base44.com/images/public/6ad8b57d9881b089c2bbeb55/fbbfa5761_generated_fbbd15f8.png";

const TILES = [
  { label: "Graphic", caption: "Stag bloom prints", tag: "Graphic" },
  { label: "Gradient", caption: "Season washes", tag: "Gradient" },
  { label: "Essentials", caption: "Everyday heavyweight", tag: "Essentials" },
];

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    (async () => {
      const page = await base44.entities.Product.filter({}, { sort: "-created_date", limit: 24 });
      if (active) {
        setProducts(page.items || []);
        setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const featured = products.filter((p) => p.is_featured).slice(0, 4);
  const heroGrid = featured.length ? featured : products.slice(0, 4);
  const rest = products.filter((p) => !heroGrid.some((h) => h.id === p.id)).slice(0, 4);

  return (
    <div>
      <section className="relative h-[78vh] min-h-[520px] w-full overflow-hidden bg-foreground">
        <Image src={HERO} alt="Show Stopper campaign" className="absolute inset-0 h-full w-full" fittingType="fill" />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/90 via-foreground/20 to-foreground/40" />
        <div className="relative mx-auto flex h-full max-w-[1600px] flex-col justify-between px-4 py-8 md:px-8 md:py-12">
          <div className="flex items-center justify-between text-background">
            <p className="font-mono text-[10px] uppercase tracking-[0.3em]">Drop 004 / 21.10.26</p>
            <p className="hidden font-mono text-[10px] uppercase tracking-[0.3em] md:block">
              T-Shirt collection
            </p>
          </div>
          <div>
            <h1 className="display-tight text-[17vw] leading-[0.82] text-background md:text-[10vw]">
              Stag
              <br />
              Bloom
            </h1>
            <div className="mt-6 flex flex-col gap-4 border-t border-background/25 pt-6 md:flex-row md:items-center md:justify-between">
              <p className="max-w-md text-sm leading-relaxed text-background/70">
                Heavyweight 240 GSM cotton, screen-printed by hand in small runs. Once the drop is
                gone, the archive closes.
              </p>
              <div className="flex flex-wrap items-center gap-3">
                <Link
                  to="/shop"
                  className="inline-flex items-center gap-2 bg-accent px-7 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-foreground transition-transform hover:-translate-y-0.5"
                >
                  Shop the collection <ArrowRight className="h-3.5 w-3.5" />
                </Link>
                <Link
                  to="/register"
                  className="inline-flex items-center gap-2 border border-background/40 px-7 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-background transition-colors hover:border-accent hover:text-accent"
                >
                  Create identity
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Marquee />

      <section className="mx-auto max-w-[1600px] px-4 pt-16 md:px-8">
        <div className="flex items-end justify-between border-b border-border pb-4">
          <div>
            <p className="mono-label">01 / Selected pieces</p>
            <h2 className="mt-2 font-display text-3xl font-extrabold uppercase tracking-tight md:text-4xl">
              The new vanguard
            </h2>
          </div>
          <Link
            to="/shop"
            className="hidden items-center gap-2 font-mono text-[11px] uppercase tracking-[0.18em] underline underline-offset-4 md:inline-flex"
          >
            View all <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
        </div>
        <div className="mt-8">
          <ProductGrid products={heroGrid} loading={loading} />
        </div>
      </section>

      <section id="story" className="mt-20 bg-foreground text-background">
        <div className="mx-auto grid max-w-[1600px] gap-0 md:grid-cols-2">
          <div className="relative aspect-[4/3] md:aspect-auto md:min-h-[620px]">
            <Image src={STILL} alt="Folded heavyweight cotton tees" className="h-full w-full" fittingType="fill" />
          </div>
          <div className="flex flex-col justify-center px-4 py-14 md:px-14">
            <p className="mono-label text-background/40">02 / The archive</p>
            <h2 className="display-tight mt-4 text-4xl text-background md:text-5xl">
              Built for the
              <br />
              new vanguard
            </h2>
            <p className="mt-6 max-w-md text-sm leading-relaxed text-background/70">
              Every Show Stopper piece starts as a drawing in a Delhi studio and ends as a numbered
              garment. We cut heavy, print by hand and refuse to restock — so what you wear never
              becomes wallpaper.
            </p>
            <dl className="mt-8 grid grid-cols-3 gap-4 border-t border-white/15 pt-6">
              {[
                ["240", "GSM cotton"],
                ["1 of 120", "Per drop"],
                ["48h", "Dispatch"],
              ].map(([value, label]) => (
                <div key={label}>
                  <dt className="font-display text-2xl font-extrabold text-accent">{value}</dt>
                  <dd className="mono-label mt-1 text-background/50">{label}</dd>
                </div>
              ))}
            </dl>
            <Link
              to="/shop?tag=Essentials"
              className="mt-10 inline-flex w-fit items-center gap-2 border-b border-accent pb-1 font-mono text-[11px] uppercase tracking-[0.2em] text-accent"
            >
              Explore essentials <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1600px] px-4 pt-20 md:px-8">
        <p className="mono-label">03 / Collections</p>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {TILES.map((tile) => (
            <Link key={tile.label} to={`/shop?tag=${encodeURIComponent(tile.tag)}`} className="group relative block overflow-hidden">
              <div className="relative aspect-[4/5] w-full overflow-hidden bg-secondary">
                <Image
                  src={heroGrid[TILES.indexOf(tile)]?.images?.[0] || HERO}
                  alt={tile.label}
                  className="h-full w-full transition-transform duration-700 group-hover:scale-105"
                  fittingType="fill"
                />
              </div>
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-foreground/80 to-transparent p-5">
                <p className="font-display text-2xl font-extrabold uppercase tracking-tight text-background">
                  {tile.label}
                </p>
                <p className="mono-label mt-1 text-background/70">{tile.caption}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {rest.length > 0 && (
        <section className="mx-auto max-w-[1600px] px-4 pt-20 md:px-8">
          <div className="flex items-end justify-between border-b border-border pb-4">
            <div>
              <p className="mono-label">04 / Just landed</p>
              <h2 className="mt-2 font-display text-3xl font-extrabold uppercase tracking-tight md:text-4xl">
                Rest of the drop
              </h2>
            </div>
          </div>
          <div className="mt-8">
            <ProductGrid products={rest} />
          </div>
        </section>
      )}

      <section className="mx-auto mt-24 max-w-[1600px] px-4 md:px-8">
        <div className="border border-foreground bg-accent px-6 py-14 md:px-16">
          <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="mono-label text-foreground/60">Members only</p>
              <h2 className="display-tight mt-3 max-w-xl text-4xl md:text-5xl">
                Members see the drop 24 hours early
              </h2>
            </div>
            <div className="max-w-sm">
              <p className="text-sm leading-relaxed text-foreground/70">
                Create an identity to save pieces to your wishlist, track every order and unlock
                early access to the next archive.
              </p>
              <Link
                to="/register"
                className="mt-6 inline-flex items-center gap-2 bg-foreground px-7 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-background"
              >
                Create identity <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}