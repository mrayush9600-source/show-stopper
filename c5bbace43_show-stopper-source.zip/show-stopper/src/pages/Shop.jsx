import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { SearchX } from "lucide-react";
import { base44 } from "@/api/base44Client";
import ProductGrid from "@/components/products/ProductGrid";
import Marquee from "@/components/Marquee";

const FILTERS = ["All", "New Drop", "Graphic", "Gradient", "Oversized", "Essentials"];
const SORTS = [
  { value: "new", label: "Newest" },
  { value: "price-asc", label: "Price ↑" },
  { value: "price-desc", label: "Price ↓" },
];

export default function Shop() {
  const [params, setParams] = useSearchParams();
  const activeTag = params.get("tag") || "All";
  const query = params.get("q") || "";
  const sort = params.get("sort") || "new";
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    const filter = {};
    if (activeTag !== "All") filter.tags = { $in: [activeTag] };
    if (query) filter.name = { $regex: query };
    const sortParam =
      sort === "price-asc" ? "price" : sort === "price-desc" ? "-price" : "-created_date";

    base44.entities.Product.filter(filter, { sort: sortParam, limit: 60 })
      .then((page) => {
        if (active) {
          setProducts(page.items || []);
          setLoading(false);
        }
      })
      .catch(() => {
        if (active) {
          setProducts([]);
          setLoading(false);
        }
      });

    return () => {
      active = false;
    };
  }, [activeTag, query, sort]);

  const updateParam = (key, value) => {
    const next = new URLSearchParams(params);
    if (!value || value === "All") next.delete(key);
    else next.set(key, value);
    setParams(next, { replace: true });
  };

  return (
    <div>
      <section className="mx-auto max-w-[1600px] px-4 pt-10 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-border pb-6">
          <div>
            <p className="mono-label">Collection</p>
            <h1 className="mt-2 font-display text-4xl font-extrabold uppercase tracking-tight md:text-6xl">
              {query ? `Search: ${query}` : "T- Shirts"}
            </h1>
            <p className="mono-label mt-3">
              {loading ? "Loading archive…" : `${products.length} pieces available`}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <label className="mono-label" htmlFor="sort">
              Sort
            </label>
            <select
              id="sort"
              value={sort}
              onChange={(e) => updateParam("sort", e.target.value)}
              className="border border-border bg-transparent px-3 py-2 font-mono text-[11px] uppercase tracking-[0.14em] outline-none"
            >
              {SORTS.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="no-scrollbar mt-5 flex gap-2 overflow-x-auto pb-1">
          {FILTERS.map((filter) => {
            const active = activeTag === filter;
            return (
              <button
                key={filter}
                onClick={() => updateParam("tag", filter)}
                className={`whitespace-nowrap border px-4 py-2 font-mono text-[10px] uppercase tracking-[0.16em] transition-colors ${
                  active
                    ? "border-foreground bg-foreground text-background"
                    : "border-border text-foreground/70 hover:border-foreground hover:text-foreground"
                }`}
              >
                {filter}
              </button>
            );
          })}
          {query && (
            <button
              onClick={() => updateParam("q", "")}
              className="whitespace-nowrap border border-destructive px-4 py-2 font-mono text-[10px] uppercase tracking-[0.16em] text-destructive"
            >
              Clear search
            </button>
          )}
        </div>

        <div className="mt-10 pb-8">
          {!loading && products.length === 0 && query ? (
            <div className="flex flex-col items-center border border-dashed border-border py-24 text-center">
              <SearchX className="h-8 w-8 text-muted-foreground" />
              <p className="mt-4 font-display text-2xl font-extrabold uppercase">No matches</p>
              <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                Nothing in the archive matches “{query}”. Try “stag”, “season” or clear the search.
              </p>
            </div>
          ) : (
            <ProductGrid products={products} loading={loading} />
          )}
        </div>
      </section>

      <Marquee />
    </div>
  );
}