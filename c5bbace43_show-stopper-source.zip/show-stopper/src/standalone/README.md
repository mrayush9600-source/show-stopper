# Show Stopper — running this repo

This archive is the complete Show Stopper storefront. It runs in two modes.

## 1. Standalone — no account, no backend

Everything lives in the browser: the catalog is bundled in `src/standalone/seed.json`,
orders and wishlist go to `localStorage`, sign-in is a demo user.

```bash
npm install
npx vite --config src/standalone/vite.config.js
```

Open the printed `http://localhost:5173`. Browse the shop, add to bag, check out,
see the order in Account, use the wishlist.

What is mocked in this mode: sign-in (one demo shopper), order emails, payment
(cash on delivery only), and data persistence beyond this browser profile.

## 2. Connected — against a real Base44 backend

This is the production setup: real accounts, database, order emails.

```bash
npm install
npm install -g base44@latest
base44 login           # free account, once per machine
base44 link            # once per clone — app id is in the Builder URL
base44 dev
```

Do not run plain `npm run dev` in this mode — it serves a UI with no backend.

## Files that matter

| Path | What it is |
| --- | --- |
| `src/pages/` | Home, Shop, Product detail, Cart, Checkout, Account, Order confirmation, auth pages |
| `src/components/` | Header, footer, cart drawer, product card/grid, UI kit |
| `src/lib/` | Cart, wishlist, auth context, helpers |
| `src/standalone/` | Local client, seed catalog, standalone Vite config |
| `base44/entities/` | Data schemas (Product, Order, WishlistItem) and access rules |
| `base44/functions/notifyOrder/` | Order confirmation email |
| `src/index.css`, `tailwind.config.js` | Design tokens and theme |

## Put it on GitHub

```bash
git init
git add .
git commit -m "Show Stopper storefront"
git branch -M main
git remote add origin https://github.com/<you>/show-stopper.git
git push -u origin main
```

`node_modules`, `dist` and `.env` files are already ignored.
