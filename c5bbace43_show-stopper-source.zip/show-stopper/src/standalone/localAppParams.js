// Standalone mode only (see src/standalone/vite.config.js).
// The storefront normally boots from Base44 app settings; offline we hand it
// a fixed set so nothing calls the hosted backend.
export const appParams = {
  appId: "standalone",
  token: "standalone-local-token",
  functionsVersion: "standalone",
  appBaseUrl: typeof window !== "undefined" ? window.location.origin : "",
};