import path from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Standalone mode: runs the whole storefront from a plain `vite` process with
// no Base44 account, CLI or backend. The two aliases below swap the hosted SDK
// client for a localStorage-backed one.
//
//   npm install
//   npx vite --config src/standalone/vite.config.js
//
const projectRoot = fileURLToPath(new URL("../..", import.meta.url));

export default defineConfig({
  root: projectRoot,
  plugins: [react()],
  resolve: {
    alias: [
      {
        find: /^@\/api\/base44Client$/,
        replacement: path.join(projectRoot, "src/standalone/localClient.js"),
      },
      {
        find: /^@\/lib\/app-params$/,
        replacement: path.join(projectRoot, "src/standalone/localAppParams.js"),
      },
      { find: /^@\//, replacement: `${path.join(projectRoot, "src")}/` },
    ],
  },
});