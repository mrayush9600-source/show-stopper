// Standalone mode only (see src/standalone/vite.config.js).
// A tiny drop-in replacement for the Base44 SDK client: the same slice of the
// API the storefront uses, backed by localStorage and the bundled catalog in
// seed.json. Nothing leaves the browser — no account, no backend, no emails.

import seedProducts from "./seed.json";

const STORAGE_KEY = "showstopper.standalone.v1";

const DEMO_USER = {
  id: "demo-user",
  full_name: "Demo Shopper",
  email: "demo@showstopper.store",
  role: "admin",
};

const DEFAULTS = {
  Order: { status: "placed", payment_method: "Cash on delivery" },
};

const uid = () =>
  typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `local-${Math.random().toString(36).slice(2)}`;

function seedState() {
  const now = Date.now();
  return {
    Product: seedProducts.map((product, index) => ({
      ...product,
      id: `seed-${index + 1}`,
      created_date: new Date(now - index * 3600000).toISOString(),
      updated_date: new Date(now - index * 3600000).toISOString(),
      created_by_id: DEMO_USER.id,
    })),
    Order: [],
    WishlistItem: [],
  };
}

function load() {
  if (typeof localStorage === "undefined") return seedState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return seedState();
    const parsed = JSON.parse(raw);
    const base = seedState();
    return { ...base, ...parsed, Product: parsed.Product?.length ? parsed.Product : base.Product };
  } catch {
    return seedState();
  }
}

const state = load();

function save() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* storage full or blocked — demo keeps working in memory */
  }
}

const compare = (a, b) => (a === b ? 0 : a > b ? 1 : -1);

function matchesCondition(value, condition) {
  if (condition === null || typeof condition !== "object") {
    return Array.isArray(value) ? value.includes(condition) : value === condition;
  }
  return Object.entries(condition).every(([operator, operand]) => {
    switch (operator) {
      case "$in":
        return Array.isArray(value)
          ? value.some((entry) => operand.includes(entry))
          : operand.includes(value);
      case "$nin":
        return Array.isArray(value)
          ? !value.some((entry) => operand.includes(entry))
          : !operand.includes(value);
      case "$ne":
        return JSON.stringify(value) !== JSON.stringify(operand);
      case "$regex":
        return new RegExp(String(operand), "i").test(String(value ?? ""));
      case "$exists":
        return operand ? value !== undefined : value === undefined;
      case "$gt":
        return compare(value, operand) > 0;
      case "$gte":
        return compare(value, operand) >= 0;
      case "$lt":
        return compare(value, operand) < 0;
      case "$lte":
        return compare(value, operand) <= 0;
      default:
        return true;
    }
  });
}

const matches = (record, query = {}) =>
  Object.entries(query).every(([field, condition]) => matchesCondition(record[field], condition));

function sortRecords(records, sort) {
  if (!sort) return records;
  const descending = sort.startsWith("-");
  const field = descending ? sort.slice(1) : sort;
  return [...records].sort((a, b) => (descending ? -1 : 1) * compare(a[field] ?? "", b[field] ?? ""));
}

function toPage(records, options = {}) {
  const limit = options.limit ?? 50;
  const start = Number(options.cursor) || 0;
  const items = records.slice(start, start + limit);
  const next = start + items.length;
  return { items, next_cursor: next < records.length ? String(next) : null, has_more: next < records.length };
}

function normalizeOptions(sortOrOptions, limit) {
  if (typeof sortOrOptions === "string") return { sort: sortOrOptions, limit: limit ?? 50 };
  return sortOrOptions || {};
}

function collection(name) {
  const rows = () => state[name] || (state[name] = []);
  const query = (criteria = {}, options = {}) =>
    sortRecords(rows().filter((record) => matches(record, criteria)), options.sort);

  return {
    async filter(criteria = {}, options = {}) {
      return toPage(query(criteria, options), options);
    },
    async list(sortOrOptions, limit) {
      const options = normalizeOptions(sortOrOptions, limit);
      return toPage(query({}, options), options);
    },
    async count(criteria = {}) {
      return rows().filter((record) => matches(record, criteria)).length;
    },
    async get(id) {
      const found = rows().find((record) => record.id === id);
      if (!found) throw new Error(`${name} not found`);
      return found;
    },
    async create(data) {
      const now = new Date().toISOString();
      const record = {
        ...(DEFAULTS[name] || {}),
        ...data,
        id: uid(),
        created_date: now,
        updated_date: now,
        created_by_id: DEMO_USER.id,
      };
      rows().unshift(record);
      save();
      return record;
    },
    async bulkCreate(list = []) {
      return Promise.all(list.map((entry) => this.create(entry)));
    },
    async update(id, data) {
      const records = rows();
      const index = records.findIndex((record) => record.id === id);
      if (index === -1) throw new Error(`${name} not found`);
      records[index] = { ...records[index], ...data, updated_date: new Date().toISOString() };
      save();
      return records[index];
    },
    async bulkUpdate(list = []) {
      return Promise.all(list.map(({ id, ...data }) => this.update(id, data)));
    },
    async updateMany(criteria = {}, update = {}) {
      const set = update.$set || update;
      const matched = rows().filter((record) => matches(record, criteria));
      await Promise.all(matched.map((record) => this.update(record.id, set)));
      return { updated: matched.length, has_more: false };
    },
    async delete(id) {
      state[name] = rows().filter((record) => record.id !== id);
      save();
      return { id };
    },
    async deleteMany(criteria = {}) {
      const keep = rows().filter((record) => !matches(record, criteria));
      const removed = rows().length - keep.length;
      state[name] = keep;
      save();
      return { deleted: removed };
    },
    subscribe() {
      return () => {};
    },
  };
}

export const base44 = {
  app: {
    async getPublicSettings() {
      return { id: "standalone", public_settings: {} };
    },
  },
  auth: {
    async me() {
      return DEMO_USER;
    },
    async isAuthenticated() {
      return true;
    },
    async updateMe(data) {
      return { ...DEMO_USER, ...data };
    },
    async loginViaEmailPassword() {
      return { user: DEMO_USER, access_token: "standalone-local-token" };
    },
    async loginWithProvider() {
      return { user: DEMO_USER, access_token: "standalone-local-token" };
    },
    async register() {
      return { ok: true };
    },
    async verifyOtp() {
      return { access_token: "standalone-local-token" };
    },
    async resendOtp() {
      return { ok: true };
    },
    async resetPasswordRequest() {
      return { ok: true };
    },
    async resetPassword() {
      return { ok: true };
    },
    setToken() {},
    logout() {},
    redirectToLogin() {},
  },
  entities: {
    Product: collection("Product"),
    Order: collection("Order"),
    WishlistItem: collection("WishlistItem"),
  },
  functions: {
    async invoke(name, payload) {
      return { data: { ok: true, function: name, mode: "standalone", payload } };
    },
  },
  integrations: {
    Core: {
      async UploadPublicFile({ file }) {
        return { file_url: URL.createObjectURL(file) };
      },
      async UploadPrivateFile({ file }) {
        return { file_uri: URL.createObjectURL(file) };
      },
      async CreateFileSignedUrl({ file_uri }) {
        return { signed_url: file_uri };
      },
    },
  },
  analytics: { track() {} },
};

export default base44;