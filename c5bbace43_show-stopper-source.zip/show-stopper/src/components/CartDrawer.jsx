import React from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { X, Minus, Plus, Trash2, ArrowRight } from "lucide-react";
import { useCart, formatPrice, FREE_SHIPPING_THRESHOLD } from "@/lib/cart";
import { Image } from "@/components/ui/image";

export default function CartDrawer() {
  const { items, isOpen, setIsOpen, setQty, remove, subtotal, shipping, total } = useCart();
  const remaining = FREE_SHIPPING_THRESHOLD - subtotal;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-[60] flex justify-end"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div
            className="absolute inset-0 bg-foreground/50 backdrop-blur-[2px]"
            onClick={() => setIsOpen(false)}
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 260 }}
            className="relative flex h-full w-full max-w-md flex-col bg-background"
          >
            <div className="flex items-center justify-between border-b border-border px-5 py-5">
              <div>
                <p className="mono-label">Manifest</p>
                <h2 className="mt-1 font-display text-xl font-extrabold uppercase tracking-tight">
                  Your bag
                </h2>
              </div>
              <button onClick={() => setIsOpen(false)} aria-label="Close bag">
                <X className="h-5 w-5" />
              </button>
            </div>

            {items.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
                <p className="font-display text-2xl font-extrabold uppercase">Your bag is empty</p>
                <p className="text-sm text-muted-foreground">
                  Start with the Stag Bloom drop — heavyweight cotton, limited run.
                </p>
                <Link
                  to="/shop"
                  onClick={() => setIsOpen(false)}
                  className="mt-2 inline-flex items-center gap-2 bg-foreground px-6 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-background"
                >
                  Shop now <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto px-5">
                  {items.map((item) => (
                    <div key={item.lineId} className="flex gap-4 border-b border-border py-5">
                      <Link
                        to={`/product/${item.slug}`}
                        onClick={() => setIsOpen(false)}
                        className="relative h-28 w-20 shrink-0 overflow-hidden bg-secondary"
                      >
                        <Image src={item.image} alt={item.name} className="h-full w-full" fittingType="fill" />
                      </Link>
                      <div className="flex flex-1 flex-col">
                        <div className="flex justify-between gap-2">
                          <Link
                            to={`/product/${item.slug}`}
                            onClick={() => setIsOpen(false)}
                            className="text-sm font-medium leading-snug"
                          >
                            {item.name}
                          </Link>
                          <button onClick={() => remove(item.lineId)} aria-label={`Remove ${item.name}`}>
                            <Trash2 className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
                          </button>
                        </div>
                        <p className="mono-label mt-1">Size {item.size}</p>
                        <div className="mt-auto flex items-center justify-between">
                          <div className="flex items-center border border-border">
                            <button
                              onClick={() => setQty(item.lineId, item.qty - 1)}
                              className="px-2 py-1"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="h-3 w-3" />
                            </button>
                            <span className="w-7 text-center font-mono text-xs tabular-nums">{item.qty}</span>
                            <button
                              onClick={() => setQty(item.lineId, item.qty + 1)}
                              className="px-2 py-1"
                              aria-label="Increase quantity"
                            >
                              <Plus className="h-3 w-3" />
                            </button>
                          </div>
                          <p className="font-mono text-xs">{formatPrice(item.price * item.qty)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t border-border bg-secondary/40 px-5 py-5">
                  {remaining > 0 && (
                    <p className="mono-label mb-3">
                      Add {formatPrice(remaining)} for free shipping
                    </p>
                  )}
                  <div className="space-y-1.5 font-mono text-[11px] uppercase tracking-[0.12em]">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>{formatPrice(subtotal)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Shipping</span>
                      <span>{shipping === 0 ? "Free" : formatPrice(shipping)}</span>
                    </div>
                    <div className="flex justify-between border-t border-border pt-2 text-sm">
                      <span>Total</span>
                      <span>{formatPrice(total)}</span>
                    </div>
                  </div>
                  <Link
                    to="/checkout"
                    onClick={() => setIsOpen(false)}
                    className="mt-5 flex items-center justify-center gap-2 bg-foreground py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-background transition-colors hover:bg-accent hover:text-foreground"
                  >
                    Checkout <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                  <Link
                    to="/cart"
                    onClick={() => setIsOpen(false)}
                    className="mt-3 block text-center font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground underline underline-offset-4"
                  >
                    View full bag
                  </Link>
                </div>
              </>
            )}
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
}