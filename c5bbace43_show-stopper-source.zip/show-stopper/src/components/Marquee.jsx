import React from "react";

const ITEMS = [
  "FREE SHIPPING OVER ₹2,999",
  "DROP 004 // STAG BLOOM LIVE NOW",
  "HEAVYWEIGHT 240 GSM COTTON",
  "MADE IN INDIA",
  "MEMBERS GET FIRST ACCESS",
];

export default function Marquee({ inverted = false }) {
  const row = [...ITEMS, ...ITEMS, ...ITEMS, ...ITEMS];
  return (
    <div
      className={
        inverted
          ? "overflow-hidden border-y border-white/10 bg-foreground py-2 text-background"
          : "overflow-hidden border-y border-border bg-background py-2"
      }
      aria-hidden="true"
    >
      <div className="marquee-track">
        {[0, 1].map((dupe) => (
          <div key={dupe} className="flex shrink-0 items-center">
            {row.map((text, i) => (
              <span
                key={`${dupe}-${i}`}
                className="flex items-center whitespace-nowrap px-5 font-mono text-[10px] uppercase tracking-[0.28em]"
              >
                {text}
                <span className="ml-5 h-1 w-1 rounded-full bg-accent" />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}