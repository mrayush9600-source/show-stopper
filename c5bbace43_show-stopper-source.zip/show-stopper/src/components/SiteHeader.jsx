import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Menu, Search, ShoppingBag, User, X, Heart } from "lucide-react";
import { useCart } from "@/lib/cart";
import Marquee from "@/components/Marquee";

const NAV = [
  { label: "New In", to: "/shop?tag=New%20Drop" },
  { label: "T-Shirts", to: "/shop" },
  { label: "Essentials", to: "/shop?tag=Essentials" },
  { label: "Racing Club", to: "/product/racing-club-t-shirt" },
];

export default function SiteHeader() {
  const { count, setIsOpen } = useCart();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [term, setTerm] = useState("");

  const submitSearch = (e) => {
    e.preventDefault();
    setSearchOpen(false);
    setMenuOpen(false);
    navigate(`/shop?q=${encodeURIComponent(term.trim())}`);
  };

  return (
    <header className="sticky top-0 z-40">
      <div className="bg-foreground text-background">
        <Marquee inverted />
      </div>

      <div className="border-b border-border bg-background/90 backdrop-blur-md">
        <div className="mx-auto grid max-w-[1600px] grid-cols-3 items-center px-4 py-4 md:px-8">
          <nav className="hidden items-center gap-6 md:flex">
            {NAV.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                className="font-mono text-[11px] uppercase tracking-[0.18em] text-foreground/70 transition-colors hover:text-foreground"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <button
            onClick={() => setMenuOpen(true)}
            className="flex items-center gap-2 md:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>

          <Link
            to="/"
            className="justify-self-center font-display text-lg font-extrabold uppercase tracking-[0.24em] md:text-2xl"
            aria-label="Show Stopper home"
          >
            Show Stopper
          </Link>

          <div className="flex items-center justify-end gap-4 md:gap-5">
            <button onClick={() => setSearchOpen((v) => !v)} aria-label="Search products">
              <Search className="h-[18px] w-[18px] transition-opacity hover:opacity-60" />
            </button>
            <Link to="/account" aria-label="Your account" className="hidden sm:block">
              <User className="h-[18px] w-[18px] transition-opacity hover:opacity-60" />
            </Link>
            <Link to="/account?tab=wishlist" aria-label="Wishlist" className="hidden sm:block">
              <Heart className="h-[18px] w-[18px] transition-opacity hover:opacity-60" />
            </Link>
            <button
              onClick={() => setIsOpen(true)}
              className="relative flex items-center gap-2"
              aria-label={`Open bag, ${count} items`}
            >
              <ShoppingBag className="h-[18px] w-[18px]" />
              <span className="font-mono text-[11px] tabular-nums">[{count}]</span>
            </button>
          </div>
        </div>

        {searchOpen && (
          <form onSubmit={submitSearch} className="border-t border-border">
            <div className="mx-auto flex max-w-[1600px] items-center gap-3 px-4 py-3 md:px-8">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                autoFocus
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                placeholder="Search the archive…"
                className="w-full bg-transparent font-mono text-xs uppercase tracking-[0.15em] outline-none placeholder:text-muted-foreground"
              />
              <button type="button" onClick={() => setSearchOpen(false)} aria-label="Close search">
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            </div>
          </form>
        )}
      </div>

      {menuOpen && (
        <div className="fixed inset-0 z-50 flex flex-col bg-foreground text-background md:hidden">
          <div className="flex items-center justify-between border-b border-white/15 px-5 py-5">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em]">Index</span>
            <button onClick={() => setMenuOpen(false)} aria-label="Close menu">
              <X className="h-5 w-5" />
            </button>
          </div>
          <nav className="flex flex-col px-5 py-6">
            {NAV.concat([
              { label: "Account", to: "/account" },
              { label: "Bag", to: "/cart" },
            ]).map((item) => (
              <Link
                key={item.label}
                to={item.to}
                onClick={() => setMenuOpen(false)}
                className="display-tight border-b border-white/10 py-4 text-4xl text-background"
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <p className="mt-auto px-5 pb-8 font-mono text-[10px] uppercase leading-relaxed tracking-[0.2em] text-background/50">
            Show Stopper / Kinetic Archive
            <br />
            Questions: beaantriksh@gmail.com
          </p>
        </div>
      )}
    </header>
  );
}