import React from "react";
import { Link } from "react-router-dom";
import { Instagram, ArrowUpRight } from "lucide-react";

export default function SiteFooter() {
  return (
    <footer className="mt-24 bg-foreground text-background">
      <div className="mx-auto max-w-[1600px] px-4 pt-16 md:px-8">
        <div className="grid gap-12 border-b border-white/10 pb-14 md:grid-cols-4">
          <div className="md:col-span-2">
            <p className="font-display text-3xl font-extrabold uppercase leading-none tracking-[0.22em]">
              Show Stopper
            </p>
            <p className="mt-5 max-w-sm font-mono text-[11px] uppercase leading-relaxed tracking-[0.18em] text-background/50">
              Heavyweight cotton, limited drops, engineered in India. Members get first access to
              every release.
            </p>
            <a
              href="mailto:beaantriksh@gmail.com"
              className="mt-6 inline-flex items-center gap-2 border-b border-accent pb-1 font-mono text-[11px] uppercase tracking-[0.18em] text-accent"
            >
              beaantriksh@gmail.com
              <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
          </div>

          <div>
            <p className="mono-label text-background/40">Shop</p>
            <ul className="mt-4 space-y-2 text-sm text-background/80">
              <li><Link to="/shop" className="hover:text-accent">T-Shirts</Link></li>
              <li><Link to="/shop?tag=New%20Drop" className="hover:text-accent">New Drop</Link></li>
              <li><Link to="/shop?tag=Gradient" className="hover:text-accent">Season Gradients</Link></li>
              <li><Link to="/shop?tag=Essentials" className="hover:text-accent">Essentials</Link></li>
            </ul>
          </div>

          <div>
            <p className="mono-label text-background/40">Account</p>
            <ul className="mt-4 space-y-2 text-sm text-background/80">
              <li><Link to="/account" className="hover:text-accent">My orders</Link></li>
              <li><Link to="/account?tab=wishlist" className="hover:text-accent">Wishlist</Link></li>
              <li><Link to="/cart" className="hover:text-accent">Bag</Link></li>
              <li><Link to="/login" className="hover:text-accent">Identity portal</Link></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col gap-3 py-6 md:flex-row md:items-center md:justify-between">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-background/40">
            © {new Date().getFullYear()} Show Stopper — All rights reserved
          </p>
          <div className="flex items-center gap-5 font-mono text-[10px] uppercase tracking-[0.2em] text-background/40">
            <span>Cash on delivery</span>
            <span>7 day returns</span>
            <Link to="/source" className="hover:text-accent">Source code</Link>
            <a href="mailto:beaantriksh@gmail.com" aria-label="Instagram" className="hover:text-accent">
              <Instagram className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}