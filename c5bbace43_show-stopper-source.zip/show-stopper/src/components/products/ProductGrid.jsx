import React from "react";
import ProductCard from "@/components/products/ProductCard";
import { Skeleton } from "@/components/ui/skeleton";

export default function ProductGrid({ products, loading, columns = 4 }) {
  const gridCols =
    columns === 3
      ? "grid-cols-2 md:grid-cols-3"
      : "grid-cols-2 md:grid-cols-3 xl:grid-cols-4";

  if (loading) {
    return (
      <div className={`grid gap-x-4 gap-y-10 md:gap-x-6 ${gridCols}`}>
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i}>
            <Skeleton className="aspect-[4/5] w-full rounded-none" />
            <Skeleton className="mt-3 h-3 w-2/3 rounded-none" />
            <Skeleton className="mt-2 h-3 w-1/3 rounded-none" />
          </div>
        ))}
      </div>
    );
  }

  if (!products?.length) {
    return (
      <div className="border border-dashed border-border py-24 text-center">
        <p className="font-display text-2xl font-extrabold uppercase">Nothing here yet</p>
        <p className="mt-2 text-sm text-muted-foreground">Try another filter or clear your search.</p>
      </div>
    );
  }

  return (
    <div className={`grid gap-x-4 gap-y-10 md:gap-x-6 ${gridCols}`}>
      {products.map((product, i) => (
        <ProductCard key={product.id} product={product} index={i} />
      ))}
    </div>
  );
}