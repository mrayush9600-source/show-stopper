import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Heart, Plus, X } from "lucide-react";
import { Image } from "@/components/ui/image";
import { useCart, formatPrice } from "@/lib/cart";
import { useWishlist } from "@/lib/wishlist";

const SIZES = ["S", "M", "L", "XL", "XXL"];

export default function ProductCard({ product, index = 0 }) {
  const { add } = useCart();
  const { isSaved, toggle } = useWishlist();
  const navigate = useNavigate();
  const [sizeOpen, setSizeOpen] = useState(false);
  const saved = isSaved(product.id);
  const sizes = product.sizes?.length ? product.sizes : SIZES;

  const handleSave = async () => {
    const done = await toggle(product);
    if (!done) navigate("/login");
  };

  return (
    <article className="group relative">
      <div className="relative overflow-hidden bg-secondary">
        <Link to={`/product/${product.slug}`} className="block">
          <div className="relative aspect-[4/5] w-full overflow-hidden">
            <Image
              src={product.images?.[0]}
              alt={product.name}
              className="h-full w-full transition-transform duration-700 ease-out group-hover:scale-[1.04]"
              fittingType="fill"
            />
          </div>
        </Link>

        {product.is_new && (
          <span className="absolute left-3 top-3 bg-accent px-2 py-1 font-mono text-[9px] uppercase tracking-[0.16em] text-foreground">
            New drop
          </span>
        )}

        <button
          onClick={handleSave}
          aria-label={saved ? "Remove from wishlist" : "Save to wishlist"}
          className="absolute right-3 top-3 grid h-8 w-8 place-items-center bg-background/80 backdrop-blur transition-colors hover:bg-background"
        >
          <Heart className={`h-4 w-4 ${saved ? "fill-foreground" : ""}`} />
        </button>

        <div className="absolute inset-x-3 bottom-3">
          {sizeOpen ? (
            <div className="flex items-center gap-1 bg-background/95 p-1.5 backdrop-blur">
              <span className="px-1 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
                Size
              </span>
              <div className="flex flex-1 items-center justify-between gap-1">
                {sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => {
                      add(product, s);
                      setSizeOpen(false);
                    }}
                    className="flex-1 py-1.5 font-mono text-[10px] uppercase hover:bg-foreground hover:text-background"
                  >
                    {s}
                  </button>
                ))}
              </div>
              <button onClick={() => setSizeOpen(false)} aria-label="Cancel">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setSizeOpen(true)}
              className="ml-auto flex items-center gap-2 bg-background/90 px-3 py-2 backdrop-blur transition-all md:translate-y-2 md:opacity-0 md:group-hover:translate-y-0 md:group-hover:opacity-100"
            >
              <span className="font-mono text-[9px] uppercase tracking-[0.18em]">Quick add</span>
              <Plus className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      <div className="flex items-start justify-between gap-3 pt-3">
        <div>
          <Link to={`/product/${product.slug}`} className="text-sm font-medium leading-snug hover:underline">
            {product.name}
          </Link>
          <p className="mono-label mt-1">
            {product.colorway || product.category}
            {product.gsm ? ` · ${product.gsm}` : ""}
          </p>
        </div>
        <div className="text-right">
          <p className="font-mono text-xs">{formatPrice(product.price)}</p>
          {product.compare_price > product.price && (
            <p className="font-mono text-[10px] text-muted-foreground line-through">
              {formatPrice(product.compare_price)}
            </p>
          )}
        </div>
      </div>
    </article>
  );
}