import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const MANAGER_EMAIL = "beaantriksh@gmail.com";

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const orderId = typeof body?.orderId === 'string' ? body.orderId : '';
    if (!orderId) return Response.json({ error: 'orderId is required' }, { status: 400 });

    let order = null;
    try {
      order = await base44.entities.Order.get(orderId);
    } catch {
      order = null;
    }
    if (!order) return Response.json({ error: 'Order not found' }, { status: 404 });
    if (order.created_by_id !== user.id && user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const rows = (order.items || [])
      .slice(0, 50)
      .map(
        (item) =>
          `<tr><td style="padding:6px 12px 6px 0">${item.name}</td><td style="padding:6px 12px 6px 0">${item.size}</td><td style="padding:6px 12px 6px 0">${item.qty}</td><td style="padding:6px 0">Rs ${item.price * item.qty}</td></tr>`
      )
      .join('');

    const html = `
      <div style="font-family:Helvetica,Arial,sans-serif;color:#111">
        <h2 style="margin:0 0 4px">New order ${order.order_number}</h2>
        <p style="margin:0 0 16px;color:#666">Total Rs ${order.total} — ${order.payment_method || 'Cash on delivery'}</p>
        <table style="font-size:14px;border-collapse:collapse">
          <thead><tr><th align="left">Item</th><th align="left">Size</th><th align="left">Qty</th><th align="left">Amount</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
        <p style="font-size:14px;margin-top:16px">
          <strong>${order.customer_name}</strong><br/>
          ${order.address}<br/>
          ${order.city}, ${order.state} ${order.pincode}<br/>
          ${order.phone} · ${order.email}
        </p>
        ${order.notes ? `<p style="font-size:13px;color:#666">Note: ${order.notes}</p>` : ''}
      </div>`;

    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: MANAGER_EMAIL,
        subject: `New order ${order.order_number} — Rs ${order.total}`,
        body: html,
      });
      return Response.json({ emailed: true });
    } catch (emailError) {
      return Response.json({ emailed: false, reason: emailError.message });
    }
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}